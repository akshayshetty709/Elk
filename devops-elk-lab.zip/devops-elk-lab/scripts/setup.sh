#!/usr/bin/env bash
# One-time preparation: checks prerequisites and turns this folder into the git
# repo that Jenkins will clone (Jenkins reads it from /workspace/repo).
set -euo pipefail
cd "$(dirname "$0")/.."

need() { command -v "$1" >/dev/null 2>&1 || { echo "ERROR: '$1' is required but not installed."; exit 1; }; }
need docker
need git
need curl
docker compose version >/dev/null 2>&1 || { echo "ERROR: Docker Compose v2 ('docker compose') is required."; exit 1; }
docker info >/dev/null 2>&1 || { echo "ERROR: the Docker daemon is not running."; exit 1; }

if [ "$(uname -s)" = "Linux" ]; then
  current="$(sysctl -n vm.max_map_count 2>/dev/null || echo 0)"
  if [ "$current" -lt 262144 ]; then
    echo "WARNING: Elasticsearch needs vm.max_map_count >= 262144 (currently $current)."
    echo "         Run:  sudo sysctl -w vm.max_map_count=262144"
  fi
fi

if [ ! -d .git ]; then
  echo "Initialising git repository on branch 'main'..."
  git init -q -b main 2>/dev/null || { git init -q; git checkout -q -b main; }
  git add -A
  git -c user.name="Lab Student" -c user.email="student@example.com" \
      commit -q -m "Initial commit: shop-app lab"
else
  echo "Git repository already present - leaving it as is."
fi

echo
echo "Setup OK. Next:  make up    (then: make kibana, make deploy, make traffic)"
