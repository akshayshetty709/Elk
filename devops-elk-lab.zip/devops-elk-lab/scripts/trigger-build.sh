#!/usr/bin/env bash
# Trigger the Jenkins pipeline from the command line.
#   scripts/trigger-build.sh [FAULT_MODE]      default: none
#   WAIT=1 scripts/trigger-build.sh none       wait for the build to finish
set -euo pipefail

FAULT="${1:-none}"
JENKINS_URL="${JENKINS_URL:-http://localhost:8080}"
JENKINS_USER="${JENKINS_USER:-admin}"
JENKINS_PASS="${JENKINS_ADMIN_PASSWORD:-admin}"
JOB="shop-app-deploy"

case "$FAULT" in
  none|payment_errors|db_slow|auth_bug|startup_crash) ;;
  *) echo "Unknown FAULT_MODE '$FAULT' (none|payment_errors|db_slow|auth_bug|startup_crash)"; exit 2 ;;
esac

cookies="$(mktemp)"
trap 'rm -f "$cookies"' EXIT
auth=(-u "${JENKINS_USER}:${JENKINS_PASS}")

crumb="$(curl -fsS "${auth[@]}" -c "$cookies" \
  "${JENKINS_URL}/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,%22:%22,//crumb)")" \
  || { echo "ERROR: cannot reach Jenkins at ${JENKINS_URL} (is it up? try: docker logs jenkins)"; exit 1; }

last_number() {
  curl -s "${auth[@]}" "${JENKINS_URL}/job/${JOB}/lastBuild/api/json?tree=number" \
    | sed -n 's/.*"number":\([0-9]*\).*/\1/p' | head -1
}
prev="$(last_number)"; prev="${prev:-0}"

code="$(curl -s -o /dev/null -w '%{http_code}' -X POST "${auth[@]}" -b "$cookies" -H "$crumb" \
  "${JENKINS_URL}/job/${JOB}/buildWithParameters" --data "FAULT_MODE=${FAULT}")"
if [ "$code" != "201" ]; then
  echo "ERROR: Jenkins answered HTTP ${code}. Is the job '${JOB}' present? (open ${JENKINS_URL})"
  exit 1
fi
echo "Build requested for ${JOB}."

if [ "${WAIT:-0}" = "1" ]; then
  echo -n "Waiting for the build to finish"
  for _ in $(seq 1 120); do
    sleep 5
    echo -n "."
    json="$(curl -s "${auth[@]}" "${JENKINS_URL}/job/${JOB}/lastBuild/api/json?tree=number,building,result" || true)"
    num="$(echo "$json" | sed -n 's/.*"number":\([0-9]*\).*/\1/p' | head -1)"
    if [ -n "$num" ] && [ "$num" -gt "$prev" ] && echo "$json" | grep -q '"building":false'; then
      echo
      echo "Build #${num}: $(echo "$json" | sed -n 's/.*"result":"\([A-Z_]*\)".*/\1/p')"
      exit 0
    fi
  done
  echo
  echo "Timed out waiting; check ${JENKINS_URL}/job/${JOB}/"
fi
