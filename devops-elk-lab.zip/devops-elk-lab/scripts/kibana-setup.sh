#!/usr/bin/env bash
# Creates the "shop-logs-*" data view and a few generic saved searches in Kibana.
set -euo pipefail
cd "$(dirname "$0")/.."

KIBANA_URL="${KIBANA_URL:-http://localhost:5601}"

echo "Waiting for Kibana at ${KIBANA_URL} (first start can take 1-2 minutes)..."
ready=0
for _ in $(seq 1 60); do
  if curl -fs "${KIBANA_URL}/api/status" 2>/dev/null | grep -Eq '"level" *: *"available"'; then
    ready=1
    break
  fi
  sleep 5
done
[ "$ready" = "1" ] || { echo "ERROR: Kibana did not become ready. Try: docker logs kibana"; exit 1; }

echo "Creating data view shop-logs-* ..."
curl -fsS -X POST "${KIBANA_URL}/api/data_views/data_view" \
  -H 'kbn-xsrf: true' -H 'Content-Type: application/json' \
  -d '{"override":true,"data_view":{"id":"shop-logs","title":"shop-logs-*","name":"Shop App Logs","timeFieldName":"@timestamp"}}' \
  >/dev/null
curl -fsS -X POST "${KIBANA_URL}/api/data_views/default" \
  -H 'kbn-xsrf: true' -H 'Content-Type: application/json' \
  -d '{"data_view_id":"shop-logs","force":true}' >/dev/null

echo "Importing saved searches ..."
curl -fsS -X POST "${KIBANA_URL}/api/saved_objects/_import?overwrite=true" \
  -H 'kbn-xsrf: true' --form file=@kibana/saved-objects.ndjson >/dev/null \
  || echo "WARNING: saved search import failed (not critical - you can build them by hand in Discover)."

echo
echo "Kibana is ready:  ${KIBANA_URL}/app/discover"
echo "(Data only appears after the app has been deployed and has received traffic.)"
