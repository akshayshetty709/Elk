#!/usr/bin/env bash
# Deploys a random "bad release" WITHOUT telling you which one.
# Your job: notice it, find it in Kibana, name the root cause, fix it.
# Reveal the answer afterwards with:  make reveal
set -euo pipefail
cd "$(dirname "$0")/.."

faults=(payment_errors db_slow auth_bug startup_crash)
pick="${faults[$((RANDOM % ${#faults[@]}))]}"

echo "$pick" > .incident
date -u +%FT%TZ >> .incident

echo "Deploying a mystery release..."
WAIT=1 ./scripts/trigger-build.sh "$pick" || true

echo
echo "An incident has been injected."
echo "  1. Generate traffic:   make traffic"
echo "  2. Investigate in Kibana (http://localhost:5601). Do NOT peek at the Jenkins build parameters."
echo "  3. Write down: symptom, first bad timestamp, build number, root cause, fix."
echo "  4. Check yourself:     make reveal   (then read docs/03-answer-key.md)"
