#!/usr/bin/env python3
"""Generate realistic background traffic against shop-app (standard library only).

    python3 scripts/traffic.py                      # 3 minutes, ~5 req/s
    python3 scripts/traffic.py --duration 600 --rps 10
    python3 scripts/traffic.py --base-url http://localhost:5000

Includes some *expected* noise (404s, wrong passwords, health checks) so you
have to learn to separate normal errors from real incidents.
"""
import argparse
import json
import random
import threading
import time
import urllib.error
import urllib.request
from collections import Counter

USERS = [("alice", "alice123"), ("bob", "bob123"), ("carol", "carol123"),
         ("dave", "dave123"), ("erin", "erin123")]
USER_IDS = {"alice": 101, "bob": 102, "carol": 103, "dave": 104, "erin": 105}


def call(base, method, path, body=None, timeout=15):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(base + path, data=data, method=method,
                                 headers={"Content-Type": "application/json",
                                          "User-Agent": "traffic-gen/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status
    except urllib.error.HTTPError as exc:
        return exc.code
    except Exception:
        return 0  # connection refused / timeout


def one_request(base):
    r = random.random()
    if r < 0.05:
        return "GET /health", call(base, "GET", "/health")
    if r < 0.35:
        return "GET /products", call(base, "GET", "/products")
    if r < 0.55:
        # ~10% of product lookups are for ids that do not exist (normal 404 noise)
        pid = random.choice([1, 2, 3, 4, 5, 6, 7, 8] * 9 + [99, 404])
        return "GET /products/<id>", call(base, "GET", "/products/%d" % pid)
    if r < 0.72:
        user, password = random.choice(USERS)
        if random.random() < 0.08:
            password = "wrong-password"  # normal 401 noise
        return "POST /login", call(base, "POST", "/login", {"username": user, "password": password})
    if r < 0.95:
        user, _ = random.choice(USERS)
        items = [{"product_id": random.randint(1, 8), "qty": random.randint(1, 3)}
                 for _ in range(random.randint(1, 3))]
        return "POST /checkout", call(base, "POST", "/checkout", {"user_id": USER_IDS[user], "items": items})
    return "GET /orders/<id>", call(base, "GET", "/orders/ORD-%06d" % random.randint(1001, 1050))


def worker(base, stop_at, delay, stats, lock):
    while time.time() < stop_at:
        label, status = one_request(base)
        with lock:
            stats[(label, status)] += 1
        time.sleep(random.uniform(0.5 * delay, 1.5 * delay))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--base-url", default="http://localhost:5000")
    parser.add_argument("--duration", type=int, default=180, help="seconds (default 180)")
    parser.add_argument("--rps", type=float, default=5, help="approx requests/second (default 5)")
    parser.add_argument("--workers", type=int, default=8, help="parallel clients (default 8)")
    args = parser.parse_args()

    delay = args.workers / max(args.rps, 0.1)
    stats, lock = Counter(), threading.Lock()
    stop_at = time.time() + args.duration
    threads = [threading.Thread(target=worker, args=(args.base_url, stop_at, delay, stats, lock), daemon=True)
               for _ in range(args.workers)]
    print("Sending ~%.1f req/s to %s for %ds (Ctrl-C to stop early)" % (args.rps, args.base_url, args.duration))
    for t in threads:
        t.start()
    try:
        while time.time() < stop_at:
            time.sleep(10)
            with lock:
                total = sum(stats.values())
                by_status = Counter()
                for (_, status), n in stats.items():
                    by_status[status] += n
            print("[%3ds left] total=%d  %s" % (max(0, int(stop_at - time.time())), total,
                                                 "  ".join("%s:%d" % (k or "ERR", v) for k, v in sorted(by_status.items()))))
    except KeyboardInterrupt:
        stop_at = 0
    for t in threads:
        t.join(timeout=20)
    print("\nDone. Totals by endpoint/status:")
    for (label, status), n in sorted(stats.items()):
        print("  %-22s %-4s %d" % (label, status or "ERR", n))


if __name__ == "__main__":
    main()
