"""
shop-app: the application Jenkins deploys in this lab.

A tiny shop API (products, login, checkout) whose only real job is to emit
realistic, structured JSON logs so you can practise troubleshooting in Kibana.

Failures are injected through FAULT_MODE (set by the Jenkins pipeline parameter
at deploy time, i.e. a "bad release"):

    none            healthy release
    payment_errors  checkout calls to the payment gateway time out
    db_slow         the database is slow / pool gets exhausted
    auth_bug        a code bug breaks login for some users
    startup_crash   the app cannot start (missing config)

Do not read the fault code paths below if you want to practise "blind".
"""
import json
import logging
import logging.handlers
import os
import random
import sys
import threading
import time
import uuid
from datetime import datetime, timezone

from flask import Flask, g, has_request_context, jsonify, request
from werkzeug.exceptions import HTTPException

SERVICE_NAME = "shop-app"
APP_VERSION = os.getenv("APP_VERSION", "dev")
BUILD_NUMBER = os.getenv("BUILD_NUMBER", "0")
GIT_COMMIT = os.getenv("GIT_COMMIT", "unknown")
LOG_FILE = os.getenv("LOG_FILE", "/var/log/app/shop.log")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

RUNTIME_FAULTS = ("none", "payment_errors", "db_slow", "auth_bug")
STARTUP_FAULTS = ("startup_crash",)
ALL_FAULTS = RUNTIME_FAULTS + STARTUP_FAULTS

FAULT = {"mode": (os.getenv("FAULT_MODE") or "none").strip().lower()}


# --------------------------------------------------------------------------
# Structured logging: one JSON object per line, to stdout AND to a file that
# Filebeat tails and ships to Elasticsearch.
# --------------------------------------------------------------------------
class JsonFormatter(logging.Formatter):
    def format(self, record):
        ts = datetime.fromtimestamp(record.created, tz=timezone.utc)
        payload = {
            "@timestamp": ts.strftime("%Y-%m-%dT%H:%M:%S.") + "%03dZ" % record.msecs,
            "level": record.levelname,
            "message": record.getMessage(),
            "service": SERVICE_NAME,
            "version": APP_VERSION,
            "build": BUILD_NUMBER,
            "git_commit": GIT_COMMIT,
            "logger": record.name,
        }
        if has_request_context():
            request_id = getattr(g, "request_id", None)
            if request_id:
                payload["request_id"] = request_id
            if getattr(g, "user_id", None) is not None:
                payload["user_id"] = g.user_id
        payload.update(getattr(record, "fields", None) or {})
        if record.exc_info and record.exc_info[0] is not None:
            etype, evalue, _ = record.exc_info
            payload["error_type"] = etype.__name__
            payload["error_message"] = str(evalue)
            payload["stack_trace"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


logger = logging.getLogger("shop")


def configure_logging():
    logger.setLevel(LOG_LEVEL)
    logger.propagate = False
    if logger.handlers:
        return
    formatter = JsonFormatter()
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            LOG_FILE, maxBytes=5_000_000, backupCount=3
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except OSError as exc:
        logger.warning(
            "file logging disabled",
            extra={"fields": {"reason": str(exc), "log_file": LOG_FILE}},
        )


def log(level, message, **fields):
    logger.log(level, message, extra={"fields": fields})


def log_exception(message, exc, **fields):
    logger.error(message, exc_info=exc, extra={"fields": fields})


configure_logging()


def startup_checks(mode):
    if mode not in ALL_FAULTS:
        log(logging.WARNING, "unrecognised release flag, using defaults", flag=mode)
        FAULT["mode"] = "none"
        return
    if mode == "startup_crash":
        log(
            logging.CRITICAL,
            "failed to initialise payment client: PAYMENT_API_KEY is not set",
            component="payment-client",
            missing_config="PAYMENT_API_KEY",
        )
        log(logging.CRITICAL, "cannot start application, exiting with code 1")
        raise SystemExit(1)


startup_checks(FAULT["mode"])

app = Flask(__name__)
app.json.sort_keys = False

log(
    logging.INFO,
    "application started",
    event="app_start",
    pid=os.getpid(),
    python=sys.version.split()[0],
)

# --------------------------------------------------------------------------
# Fake data
# --------------------------------------------------------------------------
PRODUCTS = [
    {"id": 1, "name": "Mechanical Keyboard", "price": 89.99, "stock": 42},
    {"id": 2, "name": "USB-C Hub", "price": 34.50, "stock": 120},
    {"id": 3, "name": "27in Monitor", "price": 249.00, "stock": 15},
    {"id": 4, "name": "Webcam 1080p", "price": 59.90, "stock": 60},
    {"id": 5, "name": "Laptop Stand", "price": 29.00, "stock": 80},
    {"id": 6, "name": "Noise-Cancelling Headset", "price": 129.00, "stock": 33},
    {"id": 7, "name": "Ergonomic Mouse", "price": 45.25, "stock": 75},
    {"id": 8, "name": "Desk Mat", "price": 19.99, "stock": 200},
]
PRODUCT_INDEX = {p["id"]: p for p in PRODUCTS}

USERS = {
    "alice": {"id": 101, "password": "alice123", "profile": {"email": "alice@example.com", "tier": "gold"}},
    "bob": {"id": 102, "password": "bob123", "profile": {"email": "bob@example.com", "tier": "silver"}},
    "carol": {"id": 103, "password": "carol123", "profile": {"email": "carol@example.com", "tier": "silver"}},
    # "legacy" accounts were migrated years ago and never got an email on file
    "dave": {"id": 104, "password": "dave123", "profile": {"tier": "legacy"}},
    "erin": {"id": 105, "password": "erin123", "profile": {"tier": "legacy"}},
}

ORDERS = {}
_order_lock = threading.Lock()
_order_seq = [1000]


def next_order_id():
    with _order_lock:
        _order_seq[0] += 1
        return "ORD-%06d" % _order_seq[0]


# --------------------------------------------------------------------------
# Dependencies (simulated)
# --------------------------------------------------------------------------
class DatabasePoolExhausted(Exception):
    pass


class PaymentGatewayTimeout(Exception):
    pass


def query_db(name):
    started = time.perf_counter()
    if FAULT["mode"] == "db_slow":
        time.sleep(random.uniform(2.0, 4.5))
        if random.random() < 0.15:
            log(
                logging.ERROR,
                "database connection pool exhausted",
                query=name,
                pool_size=20,
                pool_in_use=20,
                dependency="postgres",
            )
            raise DatabasePoolExhausted("connection pool exhausted (20/20 in use)")
    else:
        time.sleep(random.uniform(0.005, 0.03))
    query_ms = round((time.perf_counter() - started) * 1000, 1)
    if query_ms > 1000:
        log(logging.WARNING, "slow query", query=name, query_ms=query_ms, dependency="postgres")
    return query_ms


def charge_card(order_id, user_id, amount, attempts=3):
    for attempt in range(1, attempts + 1):
        if FAULT["mode"] == "payment_errors" and random.random() < 0.85:
            log(
                logging.WARNING,
                "payment gateway call failed, will retry",
                order_id=order_id,
                attempt=attempt,
                max_attempts=attempts,
                gateway="payments-gateway.internal",
                timeout_ms=5000,
            )
            time.sleep(0.3 * attempt)
            continue
        return "txn_" + uuid.uuid4().hex[:10]
    raise PaymentGatewayTimeout(
        "upstream payments-gateway.internal:443 timed out after 5000ms (%d attempts)" % attempts
    )


# --------------------------------------------------------------------------
# Request lifecycle: request id + one access-log line per request
# --------------------------------------------------------------------------
@app.before_request
def _begin():
    g.start = time.perf_counter()
    g.request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:12]
    g.user_id = None


@app.after_request
def _access_log(response):
    duration_ms = round((time.perf_counter() - getattr(g, "start", time.perf_counter())) * 1000, 1)
    status = response.status_code
    level = logging.ERROR if status >= 500 else logging.WARNING if status >= 400 else logging.INFO
    log(
        level,
        "%s %s %d" % (request.method, request.path, status),
        event="http_request",
        method=request.method,
        path=request.path,
        route=request.url_rule.rule if request.url_rule else None,
        status=status,
        duration_ms=duration_ms,
        client_ip=request.remote_addr,
        user_agent=request.headers.get("User-Agent", "-"),
    )
    response.headers["X-Request-ID"] = getattr(g, "request_id", "-")
    return response


@app.errorhandler(HTTPException)
def _http_error(exc):
    return jsonify(error=exc.name.lower().replace(" ", "_")), exc.code


@app.errorhandler(DatabasePoolExhausted)
def _pool_exhausted(exc):
    log_exception("database unavailable", exc, dependency="postgres")
    return jsonify(error="service_unavailable"), 503


@app.errorhandler(Exception)
def _unhandled(exc):
    log_exception("unhandled exception", exc, path=request.path)
    return jsonify(error="internal_server_error", request_id=getattr(g, "request_id", None)), 500


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------
@app.get("/health")
def health():
    # Deliberately shallow (what many real pipelines do): it proves the process
    # is up, not that checkout or login actually work.
    return jsonify(status="ok", version=APP_VERSION, build=BUILD_NUMBER)


@app.get("/products")
def list_products():
    query_db("list_products")
    return jsonify(products=PRODUCTS, count=len(PRODUCTS))


@app.get("/products/<int:product_id>")
def get_product(product_id):
    query_db("get_product")
    product = PRODUCT_INDEX.get(product_id)
    if product is None:
        log(logging.WARNING, "product not found", product_id=product_id)
        return jsonify(error="product_not_found"), 404
    return jsonify(product)


@app.post("/login")
def login():
    body = request.get_json(silent=True) or {}
    username = body.get("username")
    password = body.get("password")
    user = USERS.get(username)
    if user is None or user["password"] != password:
        log(logging.WARNING, "login failed: bad credentials", username=username)
        return jsonify(error="invalid_credentials"), 401

    g.user_id = user["id"]
    if FAULT["mode"] == "auth_bug":
        email = user["profile"]["email"]
    else:
        email = user["profile"].get("email", "n/a")
    token = uuid.uuid4().hex
    log(logging.INFO, "login ok", username=username, tier=user["profile"].get("tier"))
    return jsonify(token=token, user_id=user["id"], email=email)


@app.post("/checkout")
def checkout():
    body = request.get_json(silent=True) or {}
    user_id = body.get("user_id")
    items = body.get("items")
    if not isinstance(user_id, int) or not isinstance(items, list) or not items:
        log(logging.WARNING, "checkout rejected: invalid payload")
        return jsonify(error="invalid_payload"), 400

    g.user_id = user_id
    total = 0.0
    for item in items:
        if not isinstance(item, dict):
            return jsonify(error="invalid_item"), 400
        product = PRODUCT_INDEX.get(item.get("product_id"))
        qty = item.get("qty")
        if product is None or not isinstance(qty, int) or qty < 1:
            log(logging.WARNING, "checkout rejected: invalid item", item=item)
            return jsonify(error="invalid_item"), 400
        if qty > product["stock"]:
            log(logging.WARNING, "checkout rejected: insufficient stock",
                product_id=product["id"], requested=qty, available=product["stock"])
            return jsonify(error="insufficient_stock"), 409
        total += product["price"] * qty
    total = round(total, 2)

    order_id = next_order_id()
    try:
        transaction_id = charge_card(order_id, user_id, total)
    except PaymentGatewayTimeout as exc:
        log_exception("payment failed", exc, order_id=order_id, amount=total,
                      gateway="payments-gateway.internal")
        return jsonify(error="payment_failed", order_id=order_id), 502

    ORDERS[order_id] = {"order_id": order_id, "user_id": user_id, "amount": total,
                        "status": "paid", "transaction_id": transaction_id}
    log(logging.INFO, "order placed", order_id=order_id, amount=total,
        items_count=len(items), transaction_id=transaction_id)
    return jsonify(order_id=order_id, status="paid", amount=total), 201


@app.get("/orders/<order_id>")
def get_order(order_id):
    order = ORDERS.get(order_id)
    if order is None:
        log(logging.WARNING, "order not found", order_id=order_id)
        return jsonify(error="order_not_found"), 404
    return jsonify(order)


@app.route("/admin/fault", methods=["GET", "POST"])
def admin_fault():
    """Flip a runtime fault without redeploying (lab convenience)."""
    if request.method == "POST":
        mode = (request.get_json(silent=True) or {}).get("mode")
        if mode not in RUNTIME_FAULTS:
            return jsonify(error="invalid_mode", allowed=list(RUNTIME_FAULTS)), 400
        previous = FAULT["mode"]
        FAULT["mode"] = mode
        log(logging.WARNING, "runtime fault mode changed", previous=previous, current=mode)
    return jsonify(mode=FAULT["mode"])


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))
