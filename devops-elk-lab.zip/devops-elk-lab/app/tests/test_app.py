import json
import logging

import pytest

import app as shop

ORDER = {"user_id": 101, "items": [{"product_id": 1, "qty": 2}]}


# ---------------------------------------------------------------- happy paths
def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "ok"


def test_products_list(client):
    resp = client.get("/products")
    assert resp.status_code == 200
    assert resp.get_json()["count"] == len(shop.PRODUCTS)


def test_product_found_and_not_found(client):
    assert client.get("/products/1").status_code == 200
    missing = client.get("/products/999")
    assert missing.status_code == 404
    assert missing.get_json()["error"] == "product_not_found"


def test_login_success_and_failure(client):
    ok = client.post("/login", json={"username": "alice", "password": "alice123"})
    assert ok.status_code == 200
    assert ok.get_json()["email"] == "alice@example.com"
    bad = client.post("/login", json={"username": "alice", "password": "nope"})
    assert bad.status_code == 401


def test_legacy_user_can_login_when_healthy(client):
    resp = client.post("/login", json={"username": "dave", "password": "dave123"})
    assert resp.status_code == 200
    assert resp.get_json()["email"] == "n/a"


def test_checkout_success(client):
    resp = client.post("/checkout", json=ORDER)
    assert resp.status_code == 201
    body = resp.get_json()
    assert body["status"] == "paid"
    assert body["amount"] == pytest.approx(179.98)
    assert client.get("/orders/" + body["order_id"]).status_code == 200


def test_checkout_validation(client):
    assert client.post("/checkout", json={}).status_code == 400
    assert client.post("/checkout", json={"user_id": 1, "items": [{"product_id": 99, "qty": 1}]}).status_code == 400
    assert client.post("/checkout", json={"user_id": 1, "items": [{"product_id": 1, "qty": 9999}]}).status_code == 409


def test_unknown_route_is_json_404(client):
    resp = client.get("/does-not-exist")
    assert resp.status_code == 404
    assert resp.is_json


def test_request_id_is_echoed(client):
    resp = client.get("/health", headers={"X-Request-ID": "abc123"})
    assert resp.headers["X-Request-ID"] == "abc123"


# -------------------------------------------------------------------- logging
def test_json_formatter_shape():
    record = logging.LogRecord("shop", logging.INFO, __file__, 1, "hello %s", ("world",), None)
    record.fields = {"order_id": "ORD-1"}
    line = shop.JsonFormatter().format(record)
    data = json.loads(line)
    assert "\n" not in line
    assert data["message"] == "hello world"
    assert data["level"] == "INFO"
    assert data["order_id"] == "ORD-1"
    assert data["@timestamp"].endswith("Z")


def test_json_formatter_includes_stack_trace():
    try:
        raise KeyError("email")
    except KeyError:
        import sys
        record = logging.LogRecord("shop", logging.ERROR, __file__, 1, "boom", None, sys.exc_info())
    data = json.loads(shop.JsonFormatter().format(record))
    assert data["error_type"] == "KeyError"
    assert "Traceback" in data["stack_trace"]


# ------------------------------------------- the fault modes behave as designed
def test_fault_auth_bug_breaks_only_legacy_users(client):
    shop.FAULT["mode"] = "auth_bug"
    assert client.post("/login", json={"username": "alice", "password": "alice123"}).status_code == 200
    assert client.post("/login", json={"username": "dave", "password": "dave123"}).status_code == 500


def test_fault_payment_errors_fail_checkout(client, no_sleep, monkeypatch):
    shop.FAULT["mode"] = "payment_errors"
    monkeypatch.setattr(shop.random, "random", lambda: 0.0)
    resp = client.post("/checkout", json=ORDER)
    assert resp.status_code == 502
    assert resp.get_json()["error"] == "payment_failed"


def test_fault_db_slow_can_exhaust_pool(client, no_sleep, monkeypatch):
    shop.FAULT["mode"] = "db_slow"
    monkeypatch.setattr(shop.random, "uniform", lambda a, b: 0.0)
    monkeypatch.setattr(shop.random, "random", lambda: 0.0)
    assert client.get("/products").status_code == 503


def test_startup_crash_exits_with_code_1():
    with pytest.raises(SystemExit) as exc:
        shop.startup_checks("startup_crash")
    assert exc.value.code == 1


def test_admin_fault_toggle(client):
    assert client.post("/admin/fault", json={"mode": "db_slow"}).get_json()["mode"] == "db_slow"
    assert client.post("/admin/fault", json={"mode": "startup_crash"}).status_code == 400
    assert client.post("/admin/fault", json={"mode": "nonsense"}).status_code == 400
