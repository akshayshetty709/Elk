import os
import tempfile

# Must be set before `app` is imported so tests never write to /var/log/app.
os.environ["LOG_FILE"] = os.path.join(tempfile.gettempdir(), "shop-test.log")
os.environ.setdefault("APP_VERSION", "test")

import pytest  # noqa: E402

import app as shop  # noqa: E402


@pytest.fixture
def client():
    shop.FAULT["mode"] = "none"
    with shop.app.test_client() as test_client:
        yield test_client
    shop.FAULT["mode"] = "none"


@pytest.fixture
def no_sleep(monkeypatch):
    monkeypatch.setattr(shop.time, "sleep", lambda *_: None)
