# 05 – Extensions (level up)

Pick one at a time; commit each, deploy through Jenkins, and prove it in Kibana.

1. **Deeper smoke test (easy).** Add a stage that POSTs ~10 test checkouts and fails the build if more than 20% fail. Rerun the `payment_errors` incident: the pipeline should now go red and roll back by itself.
2. **Real health endpoint (easy).** Make `/health` verify its dependencies (simulated DB + payment client) and return 503 when they're unhealthy. Discuss liveness vs readiness.
3. **Kibana dashboard + alert (easy).** Build the "Shop service health" dashboard from the cheat sheet and an alert on error count. Export it via *Stack Management → Saved Objects → Export* and commit the `.ndjson`.
4. **Add the Jenkins build URL to logs (medium).** Pass `BUILD_URL` into the container as an env var, add it to every log line, and click from a Kibana error straight to the responsible Jenkins build.
5. **Canary / blue-green deploy (medium).** Start the new version as `shop-app-green` on another port, smoke test it, then switch traffic (e.g. with an nginx container) and keep `blue` for instant rollback.
6. **Slack/email notification (medium).** Add a `post` step that notifies on failure; include the rollback status and the Kibana link for the time window.
7. **Secrets handled properly (medium).** Make `PAYMENT_API_KEY` a Jenkins credential (`withCredentials`) injected at deploy; then the `startup_crash` incident becomes "forgot to configure the credential".
8. **Index lifecycle (medium).** Replace the daily index with an ILM policy (delete after 3 days). Understand rollover, retention and cost.
9. **Ingest pipeline (advanced).** Use an Elasticsearch ingest pipeline to add `error.class` / geoip / parse `user_agent`; compare with doing it in Filebeat.
10. **Metrics + APM (advanced).** Add Metricbeat and Elastic APM; correlate a slow trace with the logs via `request_id`.
11. **Infrastructure as code (advanced).** Port the compose stack to Kubernetes manifests or Helm, and the pipeline to deploy with `kubectl`.
12. **Chaos day.** Have a friend run `make incident` while you're not watching, then run a mock on-call handover: timeline, impact, fix, follow-ups.
