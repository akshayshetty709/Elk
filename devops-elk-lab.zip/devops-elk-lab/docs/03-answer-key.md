# 03 – Answer key (spoilers!)

For each incident: what you should see, the queries that find it, the root cause and fix.
All queries are KQL for the **Shop App Logs** data view.

---

## Incident: `payment_errors`

**Symptom:** `POST /checkout` returns 502 for most requests; everything else is fine. Jenkins is green.

**Find it**
```
level:(ERROR or CRITICAL)                         -> errors start right after the deploy
event:http_request and status >= 500              -> all on route /checkout, status 502
message:"payment failed"                          -> error_type PaymentGatewayTimeout
order_id:"<id from an error>"                     -> WARNING x1-3 "payment gateway call failed, will retry", then ERROR
```
**Evidence:** `error_message: upstream payments-gateway.internal:443 timed out after 5000ms (3 attempts)`; roughly 60% of checkouts fail; retries add latency to `/checkout`.

**Root cause:** the release cannot reach the payment gateway (timeouts after 3 retries).
**Fix:** redeploy a healthy release / roll back to the previous build; in real life also check the gateway's status and network path.
**Verify:** `payment failed` stops, `/checkout` returns 201, no ERROR lines for the new `build`.
**Prevent:** smoke/synthetic test that completes a test checkout; alert on 5xx rate per route; gateway circuit breaker + timeout budget.

---

## Incident: `db_slow`

**Symptom:** `/products` and `/products/<id>` take 2–4.5 s; ~15% return 503. Checkout and login are normal.

**Find it**
```
event:http_request and duration_ms >= 1000        -> only product routes
message:"slow query"                              -> query: list_products / get_product, dependency: postgres
message:"database connection pool exhausted"      -> pool_size 20, pool_in_use 20
event:http_request and status:503                 -> route /products
```
In Lens: average + 95th percentile of `duration_ms` split by `route` shows `/products*` far above everything else.

**Root cause:** the database dependency is slow and the connection pool is exhausted (20/20 in use).
**Fix:** redeploy healthy release / roll back; in real life investigate the DB (slow queries, locks, pool size, leaked connections).
**Prevent:** latency SLO + alert on p95, pool-usage metric, load test in the pipeline.

---

## Incident: `auth_bug`

**Symptom:** `POST /login` returns 500 for some users only.

**Find it**
```
route:"/login" and status:500
message:"unhandled exception"                     -> error_type KeyError, error_message 'email'
```
Read `stack_trace`: it points to `app.py` in `login`, at the line reading `user["profile"]["email"]`.
Check `user_id` on the failing requests: only **104 and 105** (dave, erin) fail; 101–103 succeed. These are the "legacy" accounts, whose profile has no `email`.

**Root cause:** code bug in the new release: it assumes every profile has an `email` key (uses `[]` instead of `.get()`); legacy accounts don't.
**Fix:** redeploy healthy release/rollback; real fix is a code change handling missing emails, plus a unit test using a legacy user (the repo already has one for the healthy path: see `test_legacy_user_can_login_when_healthy`).
**Prevent:** test data that covers legacy shapes; alert on 5xx on `/login`; canary deploys.

---

## Incident: `startup_crash`

**Symptom:** Jenkins "Smoke test" stage fails; pipeline red.

**What happened (Jenkins console):** the new container exited immediately, the smoke test retried `/health` 15 times, failed, printed the container logs, and the `post { failure }` block restored the previous image ("Rolling back to shop-app:N").

**Find it in Kibana**
```
level:CRITICAL
```
Message: `failed to initialise payment client: PAYMENT_API_KEY is not set` (`missing_config: PAYMENT_API_KEY`), logged by the new `build`, then `cannot start application, exiting with code 1`. After the rollback you'll see `application started` with the *older* build number again.

**Blast radius:** none for customers, because the rollback kept the previous release running (a short gap of a few seconds during the swap).
**Root cause:** the release requires `PAYMENT_API_KEY` but the deployment doesn't provide it (missing configuration).
**Fix:** supply the secret (e.g. Jenkins credentials injected into `docker run`) or revert the config requirement.
**Prevent:** validate required config in the pipeline before deploy; blue/green so the old version never goes down.

---

## Incident: runtime switch (Ticket 5)

`POST /admin/fault` writes a WARNING `runtime fault mode changed` with `previous` and `current`. That proves **when**, but not **who**: the log lacks an actor, and the endpoint is unauthenticated. Lesson: changes to production behaviour need authentication and an audit trail (user, source IP, reason).

---

## Ticket 6: noise vs signal (healthy baseline)

Expected on a healthy release:
- `404` on `/products/<id>` (a few per hundred product lookups: ids 99 / 404 don't exist) and on `/orders/<id>` (unknown order ids)
- `401` on `/login` (~8% wrong passwords)
- `400/409` occasionally from checkout validation
- **Not** expected: any `status >= 500`, any `level:ERROR`, `duration_ms >= 1000`

A good alert: *"5xx count per route > 5 in 5 minutes"* or *"ERROR log lines > 10 in 5 minutes"*, which stays quiet on a healthy baseline.
