# Postmortem: <short title>

**Date:** &nbsp; **Author:** &nbsp; **Severity:** (SEV1–SEV4) &nbsp; **Status:** draft / final

## Summary
Two or three sentences: what broke, for whom, for how long, how it was fixed.

## Impact
- Who/what was affected (routes, users, %)
- Duration: first bad timestamp → resolved timestamp
- Business impact (failed checkouts, slow pages, etc.)

## Timeline (UTC)
| Time | Event | Evidence (Kibana query / Jenkins build) |
|---|---|---|
| | Release build #N deployed | |
| | First error | |
| | Detected (by whom/what) | |
| | Root cause identified | |
| | Fix deployed (build #M) | |
| | Recovery verified | |

## Root cause
What exactly went wrong, including the error message and where it came from.

## Detection
How did we find out? How long did it take? Should an alert have fired earlier?

## Resolution
What did we do, and how did we confirm it worked?

## What went well / what went poorly / where we got lucky

## Action items
| Action | Type (prevent/detect/mitigate) | Owner | Due |
|---|---|---|---|
| | | | |

## Queries used
List the key KQL queries so the investigation can be repeated.
