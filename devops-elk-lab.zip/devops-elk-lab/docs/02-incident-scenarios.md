# 02 – Incident scenarios (tickets)

Each scenario is a support ticket. To play one: deploy the matching release in Jenkins
(**Build with Parameters → FAULT_MODE**), run `make traffic`, then investigate in Kibana.
Don't read `docs/03-answer-key.md` until you've written your own answer.

**For every incident write down:**
1. Symptom (what is broken, for whom)
2. First bad timestamp and the Jenkins build number responsible
3. Blast radius (which routes/users are affected, how many %)
4. Root cause (the exact error, and where it comes from)
5. Fix, and how you verified it
6. One change that would have caught it before production

Triage habit: *what changed?* (deploys) → *what's failing?* (errors by route) → *who?* (users, ids) → *why?* (stack trace, message) → *fix* → *verify*.

---

## Ticket 1 – "Customers say they can't pay" &nbsp;`FAULT_MODE = payment_errors`

> Support: Several customers report an error at checkout, but browsing is fine. Revenue looks down since the afternoon release. Dashboards show the service as up.

Hints (open only if stuck): Which route? Which status code? Look at WARNING lines before each ERROR for the same `order_id`.

## Ticket 2 – "The shop feels very slow" &nbsp;`FAULT_MODE = db_slow`

> Support: Product pages take several seconds to load and some customers get "service unavailable". Checkout seems normal.

Hints: Build a table of average and p95 of `duration_ms` per `route` (Lens). Which dependency is named in the WARNING/ERROR lines? What do `pool_size` and `pool_in_use` tell you?

## Ticket 3 – "Some users can't log in" &nbsp;`FAULT_MODE = auth_bug`

> Support: Alice and Bob are fine, but a few long-time customers get an error when logging in. We think it started with the last release.

Hints: Which `user_id`s appear in the failing requests? What do those users have in common? Find the file and line in the `stack_trace`.

## Ticket 4 – "Deploy failed, is prod OK?" &nbsp;`FAULT_MODE = startup_crash`

> Release manager: The pipeline went red on the smoke test. Did anything bad reach production? What happened?

Hints: Read the Jenkins console for the rollback. In Kibana look for `level:CRITICAL`, and compare the `build` values around that time.

## Ticket 5 – "Two things are wrong at once" &nbsp;(advanced)

1. Deploy `db_slow`.
2. Without redeploying, enable a second failure at runtime:
   ```bash
   curl -X POST localhost:5000/admin/fault -H 'Content-Type: application/json' -d '{"mode":"auth_bug"}'
   ```
   (Only one mode is active at a time, so the runtime switch *replaces* `db_slow`. Think about what the logs show about the change and what that means for audit trails.)
3. Questions: Can you see exactly when the mode changed? Which log line proves it? How would you find out *who* changed it if this were a real system?

## Ticket 6 – "Was it us?" (noise vs signal)

Run `make traffic` on a healthy release and answer using only Kibana:
- What is the normal error/warning rate?
- Which 4xx responses are expected (and why)?
- Build a saved search that hides the noise but still shows real problems.

Then compare with an incident and decide on an alerting threshold you would trust.
