# 04 – KQL & Kibana cheat sheet

## KQL basics (Discover search bar)

| Goal | Query |
|---|---|
| Field equals | `level:ERROR` |
| Several values | `level:(ERROR or CRITICAL)` |
| Exact phrase | `message:"payment failed"` |
| Numeric comparison | `status >= 500`, `duration_ms >= 1000` |
| AND / OR / NOT | `route:"/checkout" and not status:201` |
| Field exists | `stack_trace:*` |
| Wildcard | `route:/products*` |
| One request | `request_id:"a1b2c3d4e5f6"` |
| One deploy | `build:"12"` |
| Ignore health checks | `event:http_request and not path:"/health"` |

Tip: set the time picker first (top right). Most "no data" problems are the time range.

## Fields in this lab

`@timestamp`, `level`, `message`, `service`, `version`, `build`, `git_commit`, `logger`, `request_id`, `user_id`, `event`, `method`, `path`, `route`, `status`, `duration_ms`, `client_ip`, `user_agent`, `order_id`, `amount`, `transaction_id`, `query`, `query_ms`, `dependency`, `pool_size`, `pool_in_use`, `attempt`, `gateway`, `error_type`, `error_message`, `stack_trace`.

## Investigation recipe

1. **When?** Look at the histogram for the first spike; zoom in.
2. **What changed?** Saved search *app starts (deploy markers)*: which `build` started just before?
3. **What's failing?** `level:(ERROR or CRITICAL)`; click `route`, `error_type`, `message` in the sidebar for top values.
4. **How much?** Compare `status >= 500` with all `http_request` for the same route.
5. **Who?** Check `user_id`, `client_ip`; are the failures a subset?
6. **Why?** Open one document, read `error_message`/`stack_trace`; follow `request_id` / `order_id` across lines.
7. **Fix & verify:** after the fix the errors stop and a new `build` appears.

## Building visualisations (Lens)

Menu → **Visualize library → Create → Lens** (data view: Shop App Logs).

1. *Error rate over time:* Bar/line, X: `@timestamp`, Y: **Count** with filter `event:http_request and status >= 500`.
2. *Latency by route:* Y: **Percentile 95** of `duration_ms`, break down by `route` (Top values).
3. *Status code mix:* Donut/bar of `status` (Top values) filtered on `event:http_request`.
4. *Errors by build:* Count of `level:ERROR` broken down by `build`; shows which release is responsible.

Combine them in **Dashboard → Create → Add from library**; name it "Shop service health".

## Useful Discover moves

- Click a value in the sidebar → **filter in/out**.
- Save your query: top bar → **Save**. Reuse it in dashboards and alerts.
- Add columns instead of expanding every document.
- **Document → View surrounding documents** shows logs before/after the one you're reading.

## Alerting (Stack Management → Rules)

Create rule → **Elasticsearch query** → index `shop-logs-*`, time field `@timestamp`, query:
`{"query":{"bool":{"filter":[{"term":{"level":"ERROR"}}]}}}`, threshold `above 10` in the last `5 minutes`.
Action: *Server log* (the free tier's connector). You get an alert fired in Kibana when an incident starts.

## Checking the plumbing

```bash
curl -s localhost:9200/_cat/indices?v                  # is the shop-logs-* index there?
curl -s 'localhost:9200/shop-logs-*/_count'            # how many documents?
docker logs filebeat | tail                            # is Filebeat shipping?
docker exec shop-app tail -n 3 /var/log/app/shop.log   # is the app writing?
```
