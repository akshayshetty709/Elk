# 01 – Guided walkthrough

Goal: understand every moving part once, then solve one incident with hand-holding.
Prerequisite: `make setup && make up && make kibana` have finished.

---

## Part A – A healthy deploy

### A1. Run the pipeline
`make deploy`, or in Jenkins: **shop-app-deploy → Build with Parameters → FAULT_MODE = none → Build**.

Open the build and watch the stages: **Checkout → Unit tests → Build image → Deploy → Smoke test**.

Things to notice in the **Console Output**:
- Unit tests run *inside a container* built from the Dockerfile's `test` stage (look for `docker run`).
- The image is tagged with the build number (`shop-app:1`). That number ends up in every log line as `build`.
- `docker run -v shop_logs:/var/log/app` is how logs reach Filebeat.

Verify:
```bash
curl http://localhost:5000/health        # {"build":"1","status":"ok","version":"1.0.1"}
curl http://localhost:5000/products
docker logs shop-app                     # JSON log lines
```

### A2. Generate traffic and find your logs
```bash
make traffic
```
Kibana → **Discover** → data view **Shop App Logs** → time picker **Last 15 minutes**.

Try, one at a time, in the search bar (KQL):
```
event:http_request
event:http_request and not path:"/health"
level:WARNING
```
Add columns (hover a field → "+"): `method`, `route`, `status`, `duration_ms`, `build`.

Questions to answer:
1. What share of requests are 404 or 401? Are those a problem or normal noise?
2. Which `route` is called most?
3. Open the saved search **Shop - app starts (deploy markers)**. Which build is running?

### A3. See a deploy marker
Run `make deploy` again, then reload the **deploy markers** saved search.
You should see a second `application started` line with `build: 2`. This is how you correlate "when did it break" with "which deploy".

---

## Part B – Your first incident (guided)

### B1. Inject the failure
In Jenkins: **Build with Parameters → FAULT_MODE = `payment_errors` → Build**.

Observe: **the pipeline is green**. The smoke test only checks `/health`, so a release that breaks checkout sails through. Real pipelines have this blind spot too.

Start traffic: `make traffic`

### B2. Notice it
Kibana → Discover, time range **Last 15 minutes**:
```
level:(ERROR or CRITICAL)
```
Before the deploy there were no errors; now there are. Click the histogram at the moment errors start; zoom in with the time picker.

### B3. Narrow it down
1. Click the field `route` in the sidebar → "Visualize"/top values. Which route produces the errors?
2. Filter: `event:http_request and status >= 500`. Which status codes? Only one route?
3. Compare the error rate with the successful checkouts: `route:"/checkout"` then look at `status` values.

### B4. Find the root cause
Open one error document (`message: payment failed`) and read `error_type`, `error_message`, and `stack_trace`.
Then look at the WARNING lines just before it with the same `order_id`:
```
order_id:"ORD-001042"
```
(Use an order id from your own data.) You will see a sequence: *retry attempt 1 → 2 → 3 → payment failed*.

Write one sentence: **"Checkout fails because ____, starting at ____ (build ____)."**

### B5. Fix it
Fix = ship a healthy release. `make fix` (or Build with Parameters → `none`).
Back in Kibana, confirm:
- a new `application started` marker with a higher `build`
- `payment failed` stops appearing
- error rate returns to ~0 (apart from normal 404/401 noise)

### B6. Reflect
- Why did the pipeline stay green? How would you change the smoke test to catch this? (see `docs/05-extensions.md`)
- Which log fields made the investigation fast? Which fields would you add?

---

## Part C – A failed deploy and automatic rollback

Build with `FAULT_MODE = startup_crash`.

- The **Smoke test** stage fails, the pipeline is red, and the `post { failure }` block rolls back to the previous image. Check the console for "Rolling back".
- `curl http://localhost:5000/health` works again, and shows the *old* build number.
- In Kibana: `level:CRITICAL`. What does the message say? Which `build` logged it? That build never served traffic, which is why correlating Jenkins build numbers with log `build` values is so useful.

Continue with `docs/02-incident-scenarios.md` or drill with `make incident`.
