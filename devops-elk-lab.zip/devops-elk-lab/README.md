# DevOps Practice Lab: Jenkins → App → Logs → Kibana

A realistic, self-contained project for practising the full loop:

1. **Jenkins** tests, builds and deploys a small Python app (a shop API) as a Docker container.
2. The app writes **structured JSON logs**.
3. **Filebeat → Elasticsearch → Kibana** make those logs searchable.
4. You inject a **simulated bad release**, then **troubleshoot it in Kibana**, find the root cause, and fix it with another pipeline run.

```
                 git commit
  you ───────────────────────────►  Jenkins (:8080)
                                      │ test → build → deploy → smoke test (→ rollback on failure)
                                      ▼
                              shop-app container (:5000)
                                      │ JSON logs → shared volume "shop_logs"
                                      ▼
   Kibana (:5601) ◄── Elasticsearch (:9200) ◄── Filebeat (tails the log volume)
```

## Requirements

- Docker Desktop (or Docker Engine) with **Compose v2** (`docker compose`), `git`, `curl`, `make`, `python3`
- About **4 GB of free RAM** for Docker and ~5 GB of disk
- Ports free: 8080, 5000, 5601, 9200
- Linux only: `sudo sysctl -w vm.max_map_count=262144` (Elasticsearch requirement)
- Windows: use WSL2 and run everything inside the WSL filesystem

## Quick start (about 10 minutes the first time)

```bash
make setup      # checks prerequisites, turns this folder into the git repo Jenkins clones
make up         # builds Jenkins, starts Jenkins + Elasticsearch + Kibana + Filebeat
make kibana     # creates the Kibana data view + saved searches (waits until Kibana is ready)
make deploy     # runs the Jenkins pipeline: a healthy release
make traffic    # 3 minutes of realistic traffic against http://localhost:5000
```

Then open:

| What | URL | Login |
|---|---|---|
| Jenkins | http://localhost:8080 | `admin` / `admin` |
| Kibana (Discover) | http://localhost:5601/app/discover | none |
| The app | http://localhost:5000/products | none |

No `make`? Every target is a one-liner, see the `Makefile`.

## The practice loop

1. **Learn the tools** – follow `docs/01-guided-walkthrough.md` (healthy deploy, then one guided incident).
2. **Drill** – run `make incident`. A random bad release is deployed and *the answer is hidden*. Run `make traffic`, investigate in Kibana, and write down: symptom, first bad timestamp, build number, root cause, fix.
3. **Check yourself** – `make reveal`, then compare with `docs/03-answer-key.md`.
4. **Fix it the DevOps way** – `make fix` (redeploys a healthy release through the pipeline), and verify in Kibana that errors stop.
5. **Write the postmortem** – `docs/postmortem-template.md`.

Prefer to work from tickets instead of a random incident? Use `docs/02-incident-scenarios.md`.

## What's inside

| Path | Purpose |
|---|---|
| `Jenkinsfile` | The pipeline: checkout, unit tests, build image, deploy, smoke test, automatic rollback |
| `app/` | Flask shop API, Dockerfile (multi-stage: test + runtime), pytest suite |
| `jenkins/` | Jenkins image + Configuration-as-Code (job is created automatically) |
| `docker-compose.yml` | Jenkins, Elasticsearch, Kibana, Filebeat |
| `elk/filebeat.yml` | Ships `/var/log/shop/*.log` (NDJSON) to index `shop-logs-YYYY.MM.dd` |
| `kibana/saved-objects.ndjson` | Generic saved searches (errors, 5xx, slow requests, deploy markers) |
| `scripts/` | Traffic generator, Jenkins trigger, random-incident injector, setup helpers |
| `docs/` | Walkthrough, scenarios, answer key, KQL cheat sheet, extensions, postmortem template |

## Key log fields to know

Every line is one JSON object: `@timestamp`, `level`, `message`, `service`, `version`, `build` (the Jenkins build number), `git_commit`, `request_id`, `user_id`.
Request lines add `event: http_request`, `method`, `path`, `route`, `status`, `duration_ms`. Errors add `error_type`, `error_message`, `stack_trace`.

## Making changes and redeploying

Jenkins builds from the **git repo**, not your working directory. After editing the app:

```bash
git add -A && git commit -m "Describe your change"
make deploy            # or wait: Jenkins polls for new commits every ~2 minutes
```

## Stopping and resetting

```bash
make down     # stop everything, keep data
make clean    # stop everything and delete ALL lab data (Jenkins history, logs, indexes)
```

## Troubleshooting the lab itself

| Symptom | Fix |
|---|---|
| Elasticsearch exits immediately (Linux) | `sudo sysctl -w vm.max_map_count=262144` |
| `make deploy` says it cannot reach Jenkins | Jenkins takes ~1 minute to start; check `docker logs jenkins` |
| Jenkins job `shop-app-deploy` is missing | `docker logs jenkins` and look for Configuration-as-Code errors; make sure `make setup` ran (a `.git` folder must exist) |
| Pipeline fails at "Checkout" | The repo needs at least one commit on branch `main` (`git log`) |
| Port already in use | Stop whatever uses 8080/5000/5601/9200, or edit the ports in `docker-compose.yml` / `Jenkinsfile` |
| Kibana shows no data | Deploy the app, run `make traffic`, set the time picker to "Last 15 minutes"; check `docker logs filebeat` |
| Change not picked up by Jenkins | You must `git commit` first |

## Security note

This is a **lab**: Jenkins runs as root with the host Docker socket mounted, Elasticsearch/Kibana have security disabled, and passwords are `admin`. Never expose it to the internet or reuse this setup for production.
